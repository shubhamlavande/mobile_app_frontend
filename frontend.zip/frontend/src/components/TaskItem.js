import React from "react";

const TaskItem = ({ task, onComplete, onDelete }) => {

  const handleDelete = () => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete task?"
    );

    if (confirmDelete) {
      onDelete(task.id);
    }
  };

  return (
    <li className={task.completed ? "done" : ""}>
      {task.title}
      <div>
        <button onClick={() => onComplete(task)}>✔</button>
        <button onClick={handleDelete}>❌</button>
      </div>
    </li>
  );
};

export default TaskItem;
