import React, { useEffect, useState } from "react";
import TaskForm from "../components/TaskForm";
import TaskList from "../components/TaskList";
import { getTasks, addTask, updateTask, deleteTask } from "../api/taskApi";

const Home = () => {
  const [tasks, setTasks] = useState([]);

  const fetchTasks = async () => {
    const res = await getTasks();
    setTasks(res.data);
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  const handleAdd = async (task) => {
    await addTask(task);
    fetchTasks();
  };

  const handleComplete = async (task) => {
    await updateTask(task.id, {
      title: task.title,
      completed: !task.completed,
    });
    fetchTasks();
  };

  const handleDelete = async (id) => {
    await deleteTask(id);
    fetchTasks();
  };

  return (
    <div className="container">
      <h2>Task Manager</h2>
      <TaskForm onAdd={handleAdd} />
      <TaskList
        tasks={tasks}
        onComplete={handleComplete}
        onDelete={handleDelete}
      />
    </div>
  );
};

export default Home;
