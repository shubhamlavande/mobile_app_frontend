import React from "react";
import Home from "./pages/Home";
import "./styles/App.css";

function App() {
  return <Home />;
}

export default App;

